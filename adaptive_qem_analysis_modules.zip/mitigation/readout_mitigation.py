"""
Assignment-matrix readout mitigation.

The calibration probabilities must come from the target IBM backend.
This implementation is intentionally explicit so the correction method is
auditable in a paper.
"""
from __future__ import annotations
import numpy as np


def single_qubit_assignment_matrix(prob_meas1_prep0: float,
                                   prob_meas0_prep1: float) -> np.ndarray:
    e01 = float(prob_meas1_prep0)
    e10 = float(prob_meas0_prep1)
    return np.array([[1.0-e01, e10],
                     [e01, 1.0-e10]], dtype=float)


def kron_assignment_matrix(single_qubit_matrices: list[np.ndarray]) -> np.ndarray:
    matrix = np.array([[1.0]])
    for m in single_qubit_matrices:
        matrix = np.kron(matrix, m)
    return matrix


def counts_to_probability_vector(counts: dict[str, int | float],
                                n_qubits: int) -> tuple[list[str], np.ndarray]:
    states = [format(i, f"0{n_qubits}b") for i in range(2**n_qubits)]
    total = float(sum(counts.values()))
    if total <= 0:
        raise ValueError("Counts must contain at least one shot.")
    vector = np.array([float(counts.get(s, 0.0))/total for s in states])
    return states, vector


def mitigate_counts(counts: dict[str, int | float],
                    prob_meas1_prep0: list[float] | float,
                    prob_meas0_prep1: list[float] | float,
                    shots: int | None = None) -> dict[str, float]:
    """Return corrected probabilities as a state->probability dictionary."""
    n = len(next(iter(counts)))
    e01 = [prob_meas1_prep0] * n if isinstance(prob_meas1_prep0, (int, float)) else list(prob_meas1_prep0)
    e10 = [prob_meas0_prep1] * n if isinstance(prob_meas0_prep1, (int, float)) else list(prob_meas0_prep1)
    if len(e01) != n or len(e10) != n:
        raise ValueError("Calibration vectors must match measured bit-string width.")

    states, measured = counts_to_probability_vector(counts, n)
    A = kron_assignment_matrix([single_qubit_assignment_matrix(a, b)
                                 for a, b in zip(e01, e10)])
    corrected = np.linalg.pinv(A) @ measured
    corrected = np.clip(corrected, 0.0, None)
    total = corrected.sum()
    if total == 0:
        raise RuntimeError("Readout mitigation produced an all-zero distribution.")
    corrected /= total
    return dict(zip(states, corrected))
