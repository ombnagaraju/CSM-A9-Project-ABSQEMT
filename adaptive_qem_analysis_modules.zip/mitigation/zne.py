"""Zero-noise extrapolation utilities using local unitary folding."""
from __future__ import annotations
from typing import Callable, Sequence
import numpy as np


def fold_circuit(circuit, scale_factor: int):
    """
    Global/local unitary folding: append U U^dagger U to each non-measurement
    operation when scale_factor is an odd integer.

    For a circuit U = G_n...G_1, replacing G with G G^dagger G preserves
    the ideal unitary while increasing physical gate count.
    """
    if scale_factor < 1 or scale_factor % 2 == 0:
        raise ValueError("scale_factor must be a positive odd integer.")
    if scale_factor == 1:
        return circuit.copy()

    from qiskit import QuantumCircuit

    out = QuantumCircuit(*circuit.qregs, *circuit.cregs)
    for instruction in circuit.data:
        op, qargs, cargs = instruction.operation, instruction.qubits, instruction.clbits
        if op.name in {"measure", "barrier"}:
            out.append(op, qargs, cargs)
            continue
        out.append(op, qargs)
        for _ in range((scale_factor - 1)//2):
            out.append(op.inverse(), qargs)
            out.append(op, qargs)
    return out


def linear_extrapolate_zero_noise(scale_factors: Sequence[float],
                                  values: Sequence[float]) -> float:
    if len(scale_factors) != len(values) or len(values) < 2:
        raise ValueError("Need at least two scale/value pairs.")
    x = np.asarray(scale_factors, dtype=float)
    y = np.asarray(values, dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    return float(intercept)


def run_zne(circuit,
            executor: Callable,
            scale_factors: Sequence[int] = (1, 3, 5)) -> dict:
    """Executor must accept a circuit and return a scalar metric."""
    values = []
    for sf in scale_factors:
        folded = fold_circuit(circuit, int(sf))
        values.append(float(executor(folded)))
    return {
        "scale_factors": list(map(int, scale_factors)),
        "values": values,
        "extrapolated_zero_noise": linear_extrapolate_zero_noise(scale_factors, values),
        "execution_count": len(scale_factors),
    }
