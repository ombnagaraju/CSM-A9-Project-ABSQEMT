"""Glue layer connecting circuit/hardware features to the adaptive selector."""
from __future__ import annotations
from dataclasses import asdict
from adaptive_qem import AdaptiveQEMSelector


def choose_strategy(circuit_features: dict, hardware_features: dict,
                    selector: AdaptiveQEMSelector | None = None) -> dict:
    selector = selector or AdaptiveQEMSelector()
    decision = selector.select_from_dict(circuit_features, hardware_features)
    return asdict(decision)


def choose_from_row(row: dict, selector: AdaptiveQEMSelector | None = None) -> dict:
    circuit_features = {
        "qubits": row.get("qubits", row.get("transpiled_qubits", 0)),
        "depth": row.get("depth", row.get("transpiled_depth", 0)),
        "cx_count": row.get("cx_count", row.get("cx", 0)),
        "cz_count": row.get("cz_count", row.get("cz", 0)),
        "swap_count": row.get("swap_count", row.get("swap", 0)),
        "one_qubit_gate_count": row.get("one_qubit_gate_count", 0),
        "two_qubit_gate_count": row.get("two_qubit_gate_count", 0),
    }
    hardware_features = {
        "readout_error": row.get("readout_error", 0.0),
        "one_qubit_error": row.get("one_qubit_error", 0.0),
        "two_qubit_error": row.get("two_qubit_error", 0.0),
        "t1_us": row.get("t1_us"),
        "t2_us": row.get("t2_us"),
    }
    return choose_strategy(circuit_features, hardware_features, selector)
