# Adaptive QEM analysis modules

These modules complete the reusable analysis/mitigation layer for the IBM Quantum
adaptive error-mitigation project.

## Important
No hardware results are fabricated. Calibration values and execution results must
come from the actual IBM backend experiments.

## Next experimental sequence
1. Copy `adaptive_qem.py` into this project root.
2. Run the existing hardware benchmark notebook and save actual IBM Kingston data.
3. Use `mitigation/adaptive_runner.py` to select a strategy for each benchmark.
4. Run raw, readout-mitigated, and ZNE experiments according to the selected strategy.
5. Record job IDs, shots, calibration snapshot/time, circuit depth/gates, and results.
6. Use `analysis/metrics.py`, `fidelity.py`, and `statistics.py` for publication tables.
