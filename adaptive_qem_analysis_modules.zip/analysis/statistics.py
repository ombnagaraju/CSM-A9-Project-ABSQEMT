"""Statistical utilities for repeated quantum-hardware experiments."""
from __future__ import annotations
from typing import Iterable, Mapping
import math


def mean(values: Iterable[float]) -> float:
    x = [float(v) for v in values]
    return sum(x) / len(x) if x else math.nan


def sample_std(values: Iterable[float]) -> float:
    x = [float(v) for v in values]
    if len(x) < 2:
        return 0.0 if x else math.nan
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1))


def standard_error(values: Iterable[float]) -> float:
    x = [float(v) for v in values]
    if not x:
        return math.nan
    return sample_std(x) / math.sqrt(len(x))


def wilson_interval(successes: int, trials: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score interval for a binomial proportion."""
    if trials <= 0:
        return math.nan, math.nan
    p = successes / trials
    denom = 1.0 + z*z/trials
    center = (p + z*z/(2*trials)) / denom
    half = z * math.sqrt((p*(1-p)/trials) + z*z/(4*trials*trials)) / denom
    return max(0.0, center-half), min(1.0, center+half)


def correlation(x: Iterable[float], y: Iterable[float]) -> float:
    x, y = list(map(float, x)), list(map(float, y))
    if len(x) != len(y) or len(x) < 2:
        return math.nan
    mx, my = mean(x), mean(y)
    dx = [v-mx for v in x]
    dy = [v-my for v in y]
    sx = math.sqrt(sum(v*v for v in dx))
    sy = math.sqrt(sum(v*v for v in dy))
    if sx == 0 or sy == 0:
        return math.nan
    return sum(a*b for a,b in zip(dx,dy)) / (sx*sy)


def summarize_metric(values: Iterable[float]) -> dict:
    x = list(map(float, values))
    return {
        "n": len(x),
        "mean": mean(x),
        "std": sample_std(x),
        "sem": standard_error(x),
        "min": min(x) if x else math.nan,
        "max": max(x) if x else math.nan,
    }
