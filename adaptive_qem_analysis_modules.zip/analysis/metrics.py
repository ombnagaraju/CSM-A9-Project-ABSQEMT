"""
Publication-oriented metrics for quantum benchmark experiments.

All functions operate on count dictionaries or scalar experiment records.
No hardware data are fabricated by this module.
"""
from __future__ import annotations
from typing import Dict, Mapping, Iterable
import math


def normalize_counts(counts: Mapping[str, int | float]) -> Dict[str, float]:
    total = float(sum(counts.values()))
    if total <= 0:
        return {str(k): 0.0 for k in counts}
    return {str(k): float(v) / total for k, v in counts.items()}


def total_variation_distance(p: Mapping[str, float], q: Mapping[str, float]) -> float:
    keys = set(p) | set(q)
    return 0.5 * sum(abs(float(p.get(k, 0.0)) - float(q.get(k, 0.0))) for k in keys)


def distribution_fidelity(p: Mapping[str, float], q: Mapping[str, float]) -> float:
    """Classical Bhattacharyya fidelity: (sum sqrt(p_i q_i))^2."""
    keys = set(p) | set(q)
    overlap = sum(math.sqrt(max(0.0, float(p.get(k, 0.0))) *
                             max(0.0, float(q.get(k, 0.0))))
                   for k in keys)
    return overlap ** 2


def success_probability(counts: Mapping[str, int | float],
                        expected_states: Iterable[str]) -> float:
    probs = normalize_counts(counts)
    return sum(probs.get(str(s), 0.0) for s in expected_states)


def error_probability(success: float) -> float:
    return max(0.0, min(1.0, 1.0 - float(success)))


def absolute_improvement(baseline: float, improved: float) -> float:
    return float(improved) - float(baseline)


def relative_improvement(baseline: float, improved: float) -> float:
    baseline = float(baseline)
    if baseline == 0:
        return math.nan
    return (float(improved) - baseline) / abs(baseline)


def benchmark_metrics(counts: Mapping[str, int | float],
                      expected_states: Iterable[str]) -> dict:
    s = success_probability(counts, expected_states)
    return {
        "success_probability": s,
        "error_probability": error_probability(s),
    }
