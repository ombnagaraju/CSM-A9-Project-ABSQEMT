"""Fidelity and distance utilities used in the adaptive-QEM study."""
from __future__ import annotations
from typing import Mapping
import math

from .metrics import normalize_counts, total_variation_distance, distribution_fidelity


def classical_fidelity_from_counts(
    measured_counts: Mapping[str, int | float],
    reference_counts: Mapping[str, int | float],
) -> float:
    return distribution_fidelity(
        normalize_counts(measured_counts),
        normalize_counts(reference_counts),
    )


def tvd_from_counts(
    measured_counts: Mapping[str, int | float],
    reference_counts: Mapping[str, int | float],
) -> float:
    return total_variation_distance(
        normalize_counts(measured_counts),
        normalize_counts(reference_counts),
    )


def circuit_fidelity_approx(
    one_qubit_fidelity: float,
    two_qubit_fidelity: float,
    n_one_qubit: int,
    n_two_qubit: int,
) -> float:
    """Independent-gate product approximation; report as an approximation."""
    return (float(one_qubit_fidelity) ** int(n_one_qubit)) * (
        float(two_qubit_fidelity) ** int(n_two_qubit)
    )


def readout_assignment_fidelity(readout_error: float) -> float:
    return 1.0 - float(readout_error)
